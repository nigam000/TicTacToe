package ticTacToe;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
public class TicTacToe extends JFrame implements ActionListener{
	private JTextField t=new JTextField();
	private JTextField t1=new JTextField();
	private JButton btn=new JButton("Submit");
	private JLabel l1=new JLabel("enter player 1 name");
	private JLabel l2=new JLabel("enter player 2 name");
	private JLabel l=new JLabel("Welcome to the TicTacToe game");
	public TicTacToe() {
		add(t);
		add(t1);
		add(btn);
		add(l1);
		add(l2);
		add(l);
		
		setLayout(null);
		getContentPane().setBackground(Color.blue);
		t1.setBackground(Color.gray);
		t.setBackground(Color.gray);
		t.setForeground(Color.cyan);
		t1.setForeground(Color.cyan);
		l1.setBounds(50,10,200,50);
		l1.setForeground(Color.cyan);
		l2.setForeground(Color.cyan);
		l.setBounds(50,0,300,50);
		l.setForeground(Color.yellow);
		t.setBounds(50,50,200,50);
		l2.setBounds(50,90,200,50);
		t1.setBounds(50,130,200,50);
		btn.setBounds(100,200,100,50); 
		btn.addActionListener(this);
		btn.setForeground(Color.cyan);
		btn.setBackground(Color.red);
		setSize(300,300);
		setVisible(true);
		}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btn) {
			if (t.getText().equals("") || t1.getText().equals("")) {
				JOptionPane.showMessageDialog(this,"Please enter value in both the Field");
			}
			else {
			myConn(t.getText(),t1.getText());
			dispose();
			TicTacToe1 t0=new TicTacToe1(t.getText(),t1.getText());
			}
		}
	}
	public void myConn(String p1,String p2) {

		try{
			Class.forName("com.mysql.cj.jdbc.Driver");

			//here sonoo is the database name, root is the username and root is the password
			    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","nigam009")) {
			        //here sonoo is the database name, root is the username and root is the password
			        Statement stmt=con.createStatement();
			        stmt.executeUpdate("insert ignore into tictactoe values('"+p1+"',0,0)");
			        stmt.executeUpdate("insert ignore into tictactoe values('"+p2+"',0,0)");
			    }

			}catch(ClassNotFoundException | SQLException e){ System.out.println(e);}
}
	public static void main(String[] args) {
		new TicTacToe();
	}
}