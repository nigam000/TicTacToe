
package ticTacToe;


import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;

import javax.swing.*;

public class TicTacToe1 extends JFrame implements ActionListener {
    private JButton[][] buttons = new JButton[3][3];
    private JButton resetButton = new JButton("Reset");
    private String X;
    private String O;
    private boolean xTurn = true;
    private JLabel txt=new JLabel();
    private JButton showButton=new JButton("view Score");
    private String highestScore;	

    public TicTacToe1(String t,String t1) {
    	X=t;
    	O=t1;
    	
        setTitle("Tic Tac Toe player "+X+": X"+" player "+O+": O");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel boardPanel = new JPanel(new GridLayout(3, 3));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                JButton button = new JButton("");
                button.setBackground(Color.blue);
                button.setForeground(Color.cyan);
                button.addActionListener(this);
                buttons[row][col] = button;
                boardPanel.add(button);
            }
        }

        JPanel buttonPanel = new JPanel();
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reset();
            }
        });
        showButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		viewScores();
        	}
        });
        txt.setText(setMaxScore());
        buttonPanel.add(txt);
        buttonPanel.add(showButton);
        buttonPanel.add(resetButton);

        add(boardPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        setSize(300, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("")) {
            if (xTurn) {
                button.setText("X");
            } else {
                button.setText("O");
            }
            xTurn = !xTurn;
            if (checkWin()) {
            	
                if(xTurn!=true){
                    JOptionPane.showMessageDialog(this, "Congratulations! "+X+" won!");
                    increment(xTurn);
                    
                }
                else{
                    JOptionPane.showMessageDialog(this, "Congratulations! "+O+" won!");
                    increment(xTurn);
                }
                
                reset();
            }
            
        }
    }
    private void increment(boolean xTurn) {
    	try{
			Class.forName("com.mysql.cj.jdbc.Driver");

			//here sonoo is the database name, root is the username and root is the password
			    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","nigam009")) {
			        //here sonoo is the database name, root is the username and root is the password
			    	if(xTurn!=true) {
			        Statement stmt=con.createStatement();
			        stmt.executeUpdate("update tictactoe set Wins=Wins+1 where player_name='"+X+"';");
			        stmt.executeUpdate("update tictactoe set Loss=Loss+1 where player_name='"+O+"';");
			        txt.setText(setMaxScore());
			    	}
			    	else {
			        Statement stmt1=con.createStatement();
			        stmt1.executeUpdate("update tictactoe set Wins=Wins+1 where player_name='"+O+"';");
			        stmt1.executeUpdate("update tictactoe set Loss=Loss+1 where player_name='"+X+"';");
			        txt.setText(setMaxScore());
			    	}
			    }

			}catch(ClassNotFoundException | SQLException e){ System.out.println(e);}
    }

    private boolean checkWin() {
        String[][] board = new String[3][3];
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                board[row][col] = buttons[row][col].getText();
            }
        }
        for (int row = 0; row < 3; row++) {
            if (!board[row][0].equals("") && board[row][0].equals(board[row][1]) && board[row][0].equals(board[row][2])) {
                return true;
            }
        }
        for (int col = 0; col < 3; col++) {
            if (!board[0][col].equals("") && board[0][col].equals(board[1][col]) && board[0][col].equals(board[2][col])) {
                return true;
            }
        }
        if (!board[0][0].equals("") && board[0][0].equals(board[1][1]) && board[0][0].equals(board[2][2])) {
            return true;
        }
        if (!board[0][2].equals("") && board[0][2].equals(board[1][1]) && board[0][2].equals(board[2][0])) {
            return true;
        }
        return false;
    }

    private void reset() {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                buttons[row][col].setText("");
            }
        }
        xTurn = true;
    }
    private void viewScores() {
    	try{
			Class.forName("com.mysql.cj.jdbc.Driver");

			//here sonoo is the database name, root is the username and root is the password
			    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","nigam009")) {
			        //here sonoo is the database name, root is the username and root is the password
			        Statement stmt=con.createStatement();
			        ResultSet rs=stmt.executeQuery("select * from tictactoe where tictactoe.player_name='"+X+"';");
			        while(rs.next())
			        	JOptionPane.showMessageDialog(this,"Name: "+rs.getString(1)+"\nWins: "+rs.getInt(2)+"\nLoss: "+rs.getInt(3)+"\nRatio: "+(double)rs.getInt(2)/rs.getInt(3));
			        rs.close();
			        Statement stmt1=con.createStatement();
			        ResultSet rs1=stmt1.executeQuery("select * from tictactoe where tictactoe.player_name='"+O+"';");
			        
			        while(rs1.next())
			        	JOptionPane.showMessageDialog(this,"Name: "+rs1.getString(1)+"\nWins: "+rs1.getInt(2)+"\nLoss "+rs1.getInt(3)+"\nRatio: "+(double)rs1.getInt(2)/rs1.getInt(3));
			        rs1.close();
			    }

			}catch(ClassNotFoundException | SQLException e){ System.out.println(e);}
    }
    private String setMaxScore(){
    	try{
			Class.forName("com.mysql.cj.jdbc.Driver");

			//here sonoo is the database name, root is the username and root is the password
			    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","nigam009")) {
			        //here sonoo is the database name, root is the username and root is the password
			        Statement stmt=con.createStatement();
			        ResultSet rs=stmt.executeQuery("select Wins from tictactoe order by Wins desc limit 1;");
			        while(rs.next())
			        highestScore=Integer.toString(rs.getInt(1));
			        
			    }

			}catch(ClassNotFoundException | SQLException e){ System.out.println(e);}
    	return ("Max Score: "+highestScore);
    }

    public static void main(String[] args) {
        //new TicTacToe1();
    }
}